cryptoAnalyzer© is a free to use program to display eight meaningful analyses of various cryptocurrencies. 
cryptoAnalyzer uses coinGecko database to source its raw data and standard java libraries to format the data. 

To install cryptoAnalyzer©, head to www.cryptoAnalyzer.com and download the latest version of the jar file containing the program. 
This code will run on most IDE's.

CURRENTLY: IT IS REQUIRED TO HAVE AN UP TO DATE JDK IN ORDER TO RUN.


HOW TO USE:
Once successfully downloaded, to run the program, double click on the CryptoAnalyzer.jar file to start. Executing the program will open up a 
login window.

Valid Credentials as of Now are: 
- a for username and a for password
- a for username and c for password
- b2 for username and H1 for password
- H@ for username and Ck for password
- AG for username and K5 for password
- W6 for username and X0 for password

In no particular order, there are a total of four drop down menus that you must enter or the analyzer will not work. 

	1. Cryptocurrency - TOP LEFT - You can choose multiple cryptocurrencies and add it to a list. 
    	There may be some restricted currencies that are not allowed to be chosen. AS OF RIGHT NOW THE FOLLOWING ARE IN THE RESTRICTED LIST: XRP.    
	2. Start Date - BOTTOM RIGHT - you can choose any date that is previous to the current date. 
    	This will pull cryptocurrency data from chosen date to present.
	3. Metrics - BOTTOM MIDDLE - You can choose eight unique analyses. Price, Market Cap, Volume, Circulation, % change in Price, 
    	% change in Market Cap, % change in Volume and % change in Circulation
	4. Interval - BOTTOM RIGHT - You can choose from 4 time delays between data points. Day, Week, Month and Yearly

After all of the four selections have been made, click refresh in the bottom right corner. This will bring up four metrics: Tabular, line chart, scatter and bar chart. 
You can also change any unique selections and hit refresh. Should you encounter 0.0 results, you have hit a limit on requests/min, please wait a moment and try again.

Note that only certain cryptocurrencies are allowed to be selected as of right now. They are:
- Bitcoin
- Ethereum
- Binance Coin
- Tether
- Solana
- Cardano
- USD Coin
- XRP
- Polkadot
- Terra

CURRENTLY: COINGECKO DB HAS A 50 REQUESTS/MIN LIMIT. WE HOPE TO INCREASE THIS LIMIT IN THE FUTURE.

In the future, we hope to increase have unlimited data requests and run a server online, so that we can provide this analysis service without installation. 
If you believe in our vision, please consider donating to our crypto wallet below.

In the resources folder, you will find a file with specific test cases. Feel free to implement them and let us know the result. 

Should you find any bugs or interruptions, please let us know at admin@cryptoAnalyzer.com


CRYPTO ADDRESS: AABBCCDDEEFF1122334455
