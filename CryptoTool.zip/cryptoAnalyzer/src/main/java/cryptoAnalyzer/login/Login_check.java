package cryptoAnalyzer.login;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * This class checks a textfile to see if a credential combination is located in the textfile. 
 * It returns true if that's so, it returns false otherwise.
 * @author Henry Chen
 */
public class Login_check extends Login_abstract {
	 private String username, password;
	    private Login_check check;
    /**
 	* This constructor method initlizes the class variables username and password
    * to the user input. 
 	*/	    
	    public Login_check(String u, String p) {
	    	this.username = u;
	    	this.password = p;
	    }
    /**
 	* This method checks if the username and password combination as stored in the class
    * variables can be found in the credentials text file.
    * If yes, true is returned, else false.
 	*/	 	
    public boolean check_Credentials() throws FileNotFoundException {
    	String credential = this.username + "&" + this.password;
    	boolean flag = false;
        @SuppressWarnings("resource")
		Scanner sc = new Scanner(this.getClass().getResourceAsStream("/Login_database.txt"));
        while(sc.hasNextLine()) {
           String line = sc.nextLine();
           if(line.equals(credential)) {
              flag = true;
           }
        }
        if(flag == true) {
        	return true;
        } 
        else {
        	return false;
        }

    }
}
