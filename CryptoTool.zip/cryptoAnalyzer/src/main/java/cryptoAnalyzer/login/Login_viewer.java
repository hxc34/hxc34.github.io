package cryptoAnalyzer.login;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import javax.swing.JOptionPane;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import cryptoAnalyzer.gui.*;
/**
 * This class creates a login gui that enables a user to enter their username and password. 
 * The class then calls a proxy class in order to be able to check if entered credential combinations
 * are kept in a text file in the system.
 * If the credentials match something in the textfile, the login gui will allow the user access
 * to the main gui.
 * Otherwise, an error is thrown to the user, and the gui closes. 
 * @author Henry Chen
 */
public class Login_viewer{
	static JTextArea display;
	static JTextArea username;
	static JTextArea password;
	static JButton submit;
	static JFrame frame1, frame2;
    /**
 	* This constructor method creates the actual gui, such as setting up the labels, buttons,
    * the layout, textboxes, size etc.
    * It also sets up action listners allow you to use the tab keys to navigate between the textboxes. 
 	*/
	private static void Login_viewer() {
		frame1 = new JFrame ("Login");
		frame1.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
				
		JPanel north = new JPanel();
		
		JLabel usernameLabel = new JLabel("        Username: ");
		username = new JTextArea(4, 16);
		JScrollPane scrollPaneUsername = new JScrollPane(username);
		north.add(usernameLabel);
		scrollPaneUsername.setVerticalScrollBarPolicy(
		            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		username.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    if (e.getModifiersEx() > 0) {
                    	username.transferFocusBackward();
                    } else {
                    	username.transferFocus();
                    }
                    e.consume();
                }
            }
        });
		north.add(scrollPaneUsername, BorderLayout.NORTH);
				
		JLabel passwordLabel = new JLabel("        Password: ");
		password = new JTextArea(4, 16);
		JScrollPane scrollPanePassword = new JScrollPane(password);
		north.add(passwordLabel);
		scrollPanePassword.setVerticalScrollBarPolicy(
		            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		password.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    if (e.getModifiersEx() > 0) {
                    	password.transferFocusBackward();
                    } else {
                    	password.transferFocus();
                    }
                    e.consume();
                }
            }
        });
		north.add(scrollPanePassword, BorderLayout.NORTH);

		JPanel south = new JPanel();
		display = new JTextArea(1, 32);
		south.add(display);
		
		submit = new JButton("Submit");
		submit.setActionCommand("submit");
		ButtonHandler click = new ButtonHandler ();
		submit.addActionListener(click);
		north.add(submit);
		
		frame1.getContentPane ().add (north);
		frame1.setSize(900, 600);
		frame1.pack();
		frame1.setVisible(true);
	}
    /**
 	* This method sets up action listners that defines what happens when a button is clicked. 
    * Specifically, when the button is clicked, the user's text input in the textboxes is read,
    * and a Login method is called to check if those text inputs representing username and password
    * constitute a correct combination that's on the system's credentails text file.
    * If the user inputs match a credential combination, then the login gui is closed and the main gui is displayed.
    * Otherwise, an error is displayed and the gui closes. 
 	*/	
    private static class ButtonHandler implements ActionListener
    {
        public void actionPerformed (ActionEvent e)
        {
        	
            String click = e.getActionCommand ();
            if (click.equals ("submit"))
            {
            	
            	String input1 = username.getText ();
            	String input2 = password.getText ();
            	boolean sucessfull = false;
            	Login login = new Login(input1,input2);
            	try {
            		sucessfull = login.check_Credentials();
				} catch (FileNotFoundException e1) {
					System.out.println("Credential file not found.");
				}
            	if (sucessfull == true) {
            		MainUI.display();
            		frame1.dispose();
            	}
            	else {
                	JOptionPane.showMessageDialog(null, "Sorry, but your credentails could not be found. The application will now exit.", "Error", 
                			JOptionPane.WARNING_MESSAGE);
                	System.exit(0);
            	}
            }
        }

    }
    /**
 	* This method initlizes an instance of the login gui.
 	*/	    
	public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater (new Runnable ()
        {
            public void run ()
            {
            	Login_viewer();
            }
        }
        );
	}
}
