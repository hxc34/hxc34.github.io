package cryptoAnalyzer.login;
import java.io.FileNotFoundException;
/**
 * This class acts as a proxy class between Login_viewer and Login_check classes.
 * It returns a boolean variable to Login_viewer by calling Login_check for the former class.
 * @author Henry Chen
 * Student ID: 251166178
 */
public class Login extends Login_abstract{
    private String username, password;
    private Login_check check;
    /**
 	* This constructor method initlizes the class variables u and p
    * @param u - username string
    * @param p - password string
 	*/
    public Login(String u, String p) {
    	this.username = u;
    	this.password = p;
    }
    /**
 	* This method creates a new Login_check object with the class variables u and p.
    * That create object then calls a Login_check method which is returned by this class
	* @return boolean
 	*/    
    public boolean check_Credentials() throws FileNotFoundException {
    	if (check == null) {
    		check = new Login_check(this.username,this.password);
    	}
    	return check.check_Credentials();
    }
}
