package cryptoAnalyzer.login;
import java.io.FileNotFoundException;
/**
 * Abstract class Login_abstract acts as an abstract class for the other login related classes to extend from
 * Particularily, it provides an abstract method check_Credentials() that other login classes can extend.
 * @author Henry Chen
 * Student ID: 251166178
 */
public abstract class Login_abstract {
    /**
 	* This abstract method is designed to return a boolean, and can throw FileNotFoundExceptions. 
 	*/
	public abstract boolean check_Credentials() throws FileNotFoundException;
}
