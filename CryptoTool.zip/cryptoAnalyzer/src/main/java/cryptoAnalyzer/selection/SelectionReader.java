package cryptoAnalyzer.selection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Class SelectionReader parses, converts and extrapolates the user's selections before being sent off to the analysis classes
 * @author Artur Krupa
 *
 */
public class SelectionReader {

	//CLASS VARIABLES
	
	//dates stores all of the dates for which data needs to be pulled from
    private ArrayList<String> dates = new ArrayList<String>();
    
    //selection stores all of the users selections
    private Selections selection;
    
    //CONSTRUCTOR

    /**
     * SelectionReader reads the user selections and parses and extrapolates the user's selection information before being sent to the analysis classes
     * @param selections The users inputed selections
     */
    public SelectionReader(Selections selections){
        selection = selections;
        
        //Use a calendar to get the user's starting date, use the formatter to convert the date to the required string format
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        
        //Set the calendar's date to the users start date
        cal.setTime(selection.getStartDate());

        /**
         * Depending on the users selected interval, get each date that information will be required for and store it in the dates list
         */
       if (selection.getInterval().contentEquals("Daily")){
            while (cal.getTime().before(new Date())){
                dates.add(formatter.format(cal.getTime()));
                cal.add(Calendar.DATE, 1);
            }
       }
       else if (selection.getInterval().contentEquals("Weekly")){
            while (cal.getTime().before(new Date())){
                dates.add(formatter.format(cal.getTime()));
                cal.add(Calendar.DATE, 7);
            }
       }
       else if (selection.getInterval().contentEquals("Monthly")){
            while (cal.getTime().before(new Date())){
                dates.add(formatter.format(cal.getTime()));
                cal.add(Calendar.DATE, 30);
            }
       }
       else if (selection.getInterval().contentEquals("Yearly")){
            while (cal.getTime().before(new Date())){
                dates.add(formatter.format(cal.getTime()));
                cal.add(Calendar.DATE, 365);
            }
       }
    }

    //METHODS
    
    /**
     * getSelectedCrypto() returns the users selected crypto currencies
     * @return The user's selected crypto currencies
     */
    public ArrayList<String> getSelectedCrypto(){	
    	return selection.getSelectedCrypto();
    }

    /**
     * getDates() returns the required dates that information is needed for
     * @return All dates that need information
     */
    public ArrayList<String> getDates(){
        return dates;
    }

    /**
     * getAnalysis() returns the user's selected analysis type
     * @return The user's selected analysis
     */
    public String getAnalysis(){
        return selection.getAnalysis();
    }

    /**
     * getInterval() returns the user's selected interval
     * @return The user's selected analysis
     */
    public String getInterval(){
        return selection.getInterval();
    }    
}
