package cryptoAnalyzer.selection;

import java.util.ArrayList;
import java.util.Date;

/**
 * Class Selections stores the user's selections that they entered to in the MainUI
 * @author Artur Krupa
 *
 */
public class Selections {
	
	//CLASS VARIABLES
	
	//List crypto stores the user's selected cryptocurrencies in a list
    private ArrayList<String> crypto = new ArrayList<String>();
    
    //date stores the users selected start date
    private Date date;
    
    //analysis stores the users selected analysis type
    private String analysis;
    
    //interval stores the interval of when to retrieve information for
    private String interval;
    
    //CONSTRUCTOR
    
    /**
     * Selections() creates a new container to store the users selections
     */
    public Selections() {}

    //METHODS
    
    /**
     * getSelectedCrypto() returns the list of the users selected crypto
     * @return The list of the users selected crypto
     */
    public ArrayList<String> getSelectedCrypto(){
        return crypto;
    }
    
    /**
     * addCrypto() adds a crypto currency to the selected crypto list
     * @param addCrypto The crypto currency to add to the selected list
     */
    public void addCrypto(String addCrypto){
        crypto.add(addCrypto);
    }
    
    /**
     * removeCrypto() removes a crypto currency from the selected crypto list
     * @param removeCrypto
     */
    public void removeCrypto(String removeCrypto){
        crypto.remove(removeCrypto);
    }

    /**
     * setStartDate() sets the user's selected start date for information pulling
     * @param startDate The users selected start date
     */
    public void setStartDate(Date startDate){
        date = startDate;
    }

    /**
     * getStartDate() returns the user's selected start date
     * @return The user's start date
     */
    public Date getStartDate(){
        return date;
    }
    
    /**
     * setAnalysis set's the user's selected analysis
     * @param setAnalysis The analysis to set the user's selected analysis to
     */
    public void setAnalysis(String setAnalysis){
        analysis = setAnalysis;
    }

    /**
     * getAnalysis() returns the user's selected analysis
     * @return The user's selected analysis
     */
    public String getAnalysis(){
        return analysis;
    }

    /**
     * setInterval() set's the user's selected interval
     * @param setInterval The interval to set the user's selected interval to
     */
    public void setInterval(String setInterval){
        interval = setInterval;
    }
    
    /**
     * getInterval() returns the user's selected interval
     * @return The user's selected interval
     */
    public String getInterval(){
        return interval;
    }
    
}
