
package cryptoAnalyzer.adapter;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
/**
 * @author Xu Wang
 * Student ID: 250748901
 * AdapterPrice provides an adapter layer between database and analysis. This class allows the system to receive input from multiple databases with multiple types of packages.
 * Simply put, adapter class reformats any given output so that analysis classes can use them properly.
 * This class thus provides an adapter method
 */ 
public class AdapterPrice {
	
	/** This method calls on getDataForCrypto method for creating the json object holding the
	 * required cryptocurrency data(price) and then it reformats it so that the analysis can use it. 
	 * @param id - id of the selected cryptocurrency
	 * @param date - dates of which data to pull
	 * @return Price object which holds the data for analysis
	 */
    public double getPriceForCoin(String id, String date) {
        double price = 0.0;

      	//creates a json object to store the pulled data
        JsonObject jsonObject = getDataForCrypto(id, date);
      
      	//if json object is not null
        if (jsonObject != null) {
          	
          	//if the pulled data is not null
            if (jsonObject.get("market_data") != null) {
              	//stores the pulled data in usable form
                JsonObject marketData = jsonObject.get("market_data").getAsJsonObject();
                JsonObject currentPrice = marketData.get("current_price").getAsJsonObject();
                price = currentPrice.get("cad").getAsDouble();
            }
        }
		//returns price
        return price;
    }
    /** This method currently tries to connect to coinGecko, to create and return a data object jsonObject.
	 * @param id - id of the selected cryptocurrency
	 * @param date - dates of which data to pull
	 * @return jason object that is in coingecko defined format. This feeds into the adapter method that transforms into
	 * usable data in analysis
	 */
    private JsonObject getDataForCrypto(String id, String date) {

        String urlString = String.format(
                "https://api.coingecko.com/api/v3/coins/%s/history?date=%s", id, date);

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            int responsecode = conn.getResponseCode();
            if (responsecode == 200) {
                String inline = "";
                Scanner sc = new Scanner(url.openStream());
                while (sc.hasNext()) {
                    inline += sc.nextLine();
                }
                sc.close();
                JsonObject jsonObject = new JsonParser().parse(inline).getAsJsonObject();
                return jsonObject;
            }

        } catch (IOException e) {
            System.out.println("Something went wrong with the API call.");
        }
        return null;
    }
}
