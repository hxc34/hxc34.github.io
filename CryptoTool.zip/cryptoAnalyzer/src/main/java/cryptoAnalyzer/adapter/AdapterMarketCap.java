
package cryptoAnalyzer.adapter;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
/**
 * @author Xu Wang
 * AdapterMarketCap provides a layer between database and analysis. This class allows the system to receive input from multiple databases with multiple types of packages.
 * Simply put, adapter class reformats any given output so that analysis classes can use them properly.
 * This class thus provides an adapter method.
 */
public class AdapterMarketCap {


	/** This method creates a json object holding the
	 * required crypto data(market cap) and then it reformats it so that the analysis can use it.
	 * @param id - id of the selected cryptocurrency
	 * @param date - dates of which data to pull
	 * @return MarketCap object which holds the data for market cap analysis
	 */
    public double getMarketCapForCoin(String id, String date) {
        double MarketCap = 0.0;
      
		//Creates a json object to store the data
        JsonObject jsonObject = getDataForCrypto(id, date);
      
      	//if json object is not null
        if (jsonObject != null) {
          
          	//if the pulled data is not null
            if (jsonObject.get("market_data") != null) {
              
              	//formats the pulled data into usable object
                JsonObject marketData = jsonObject.get("market_data").getAsJsonObject();
                JsonObject currentPrice = marketData.get("market_cap").getAsJsonObject();
                MarketCap = currentPrice.get("cad").getAsDouble();
            }
        }
		//returns market cap object 
        return MarketCap;
    }
    /**This method currently trys to connect to coinGecko and creates and returns a data object jsonObject.
     * If it fails to do so and an error occurs, it will inform the user of the error.
	 * @param id - id of the selected cryptocurrency
	 * @param date - dates of which data to pull
	 * @return jason object that is in coingecko defined format. This feeds into the adapter method that transforms into
	 * usable data in analysis
	 */
    private JsonObject getDataForCrypto(String id, String date) {

        String urlString = String.format(
                "https://api.coingecko.com/api/v3/coins/%s/history?date=%s", id, date);

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            int responsecode = conn.getResponseCode();
            if (responsecode == 200) {
                String inline = "";
                Scanner sc = new Scanner(url.openStream());
                while (sc.hasNext()) {
                    inline += sc.nextLine();
                }
                sc.close();
                JsonObject jsonObject = new JsonParser().parse(inline).getAsJsonObject();
                return jsonObject;
            }

        } catch (IOException e) {
            System.out.println("Something went wrong with the API call.");
        }
        return null;
    }
}
