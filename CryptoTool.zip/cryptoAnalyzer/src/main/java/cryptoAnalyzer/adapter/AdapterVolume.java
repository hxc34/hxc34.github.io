
package cryptoAnalyzer.adapter;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
/**
 * @author Xu Wang
 * AdapterPrice provides an adapter layer between database and analysis. This class allows the system to receive input from multiple databases with multiple types of packages.
 * Simply put, adapter class reformats any given output so that analysis classes can use them properly.
 * This class thus provides an adapter method.
 */
public class AdapterVolume {
	
	/** This method calls on getDataForCrypto method for creating the json object holding the
	 * required cryptocurrency data(volume) and then it reformats it so that the analysis can use it. 
	 * @param id - id of the selected cryptocurrency
	 * @param date - dates of which data to pull
	 * @return volume object which holds the data for analysis
	 */
    public double getVolumeForCoin(String id, String date) {
        double volume = 0.0;

      //creates a json object to store pulled data
        JsonObject jsonObject = getDataForCrypto(id, date);
      
      	//if the json object is not null
        if (jsonObject != null) {
          
          	//if the pulled data is not null
            if (jsonObject.get("market_data") != null) {
              
              	//stores the pulled data in usable form
                JsonObject marketData = jsonObject.get("market_data").getAsJsonObject();
                JsonObject currentPrice = marketData.get("total_volume").getAsJsonObject();
                volume = currentPrice.get("cad").getAsDouble();
            }
        }
		
      	//returns volume
        return volume;
    }
    /** This method currently tries to connect to coinGecko to create and return a data object jsonObject.
     * If this fails, a error is displayed.
	 * @param id - id of the selected cryptocurrency
	 * @param date - dates of which data to pull
	 * @return jason object that is in coingecko defined format. This feeds into the adapter method that transforms into
	 * usable data in analysis
	 */
    private JsonObject getDataForCrypto(String id, String date) {

        String urlString = String.format(
                "https://api.coingecko.com/api/v3/coins/%s/history?date=%s", id, date);

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            int responsecode = conn.getResponseCode();
            if (responsecode == 200) {
                String inline = "";
                Scanner sc = new Scanner(url.openStream());
                while (sc.hasNext()) {
                    inline += sc.nextLine();
                }
                sc.close();
                JsonObject jsonObject = new JsonParser().parse(inline).getAsJsonObject();
                return jsonObject;
            }

        } catch (IOException e) {
            System.out.println("Something went wrong with the API call.");
        }
        return null;
    }
}
