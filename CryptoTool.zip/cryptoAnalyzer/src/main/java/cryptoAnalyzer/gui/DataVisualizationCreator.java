package cryptoAnalyzer.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYSplineRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import cryptoAnalyzer.coin.*;
/**
 * DataVisualizationCreator
 * @author contributions by: Xu Wang, Artur Krupa
 * Student ID: 250748901, 251190423
 *DataVisualizationCreator provides the methods to transfer given data into visual graphs. After user has made their selections,
 *this class utilized XYplots to create four graphs, a table, time series which is similar to a line graph, a scatter plot and a bar graph
 */
public class DataVisualizationCreator {
	
	/**
	 * createCharts() creates all the required charts for the MainUI to display the analysis data
	 * @param coins The coins and their data that we wish to display data of
	 * @param analysis The type of analysis data that will be displayed
	 * @param interval The interval of the analysis data
	 */
	public void createCharts(ArrayList<Coin> coins, String analysis, String interval) {
		createTableOutput(coins, analysis, interval);
		createTimeSeries(coins, analysis, interval);
		createScatter(coins, analysis, interval);
		createBar(coins, analysis, interval);
	}
	
	/**Method creates and displays user defined requirements in a tabular format
	 * @param coins - an array list of user selected coins
	 * @param analysis - The type of analysis of the data
	 * @param interval - interval between data points
	 */
	private void createTableOutput(ArrayList<Coin> coins, String analysis, String interval) {

		/**
		 * 
		 */
		
		//Create an object array columnNames that will store the names of the columns of the table
		Object[] columnNames = new Object[coins.get(0).getData().size()+1];
		
		//Set the first column name to cryptocurrency
		columnNames[0] = "Cryptocurrency";
		
		//Add each date that data needs to be displayed into the columnNames array to add them as column names
		for (int count = 1; count < coins.get(0).getData().size() +1; count++) {
			columnNames[count] = coins.get(0).getData().get(count-1).getDate();
		}
		

		//Create a 2 dimensional object array to store the conents of the table
		Object[][] data = new Object[coins.size()][columnNames.length];
		
		//For each row, or coin in the table
		for (int i = 0; i < coins.size(); i++) {
			
			//For each column of data for each coin
			for (int x = 0; x < coins.get(i).getData().size() + 1; x++) {
				
				//Add the name of the coin if we are in the first column
				if (x == 0) {
					data[i][x] = coins.get(i).getName();
				}
				
				//Otherwise add the data of the coin in the other columns
				else {
					data[i][x] = String.format("%.2f", coins.get(i).getData().get(x-1).getData());
				}
			}
		}
		
		//Create a new table with of comumnNames and data
		JTable table = new JTable(data, columnNames);
		//table.setPreferredSize(new Dimension(600, 300));
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBorder (BorderFactory.createTitledBorder (BorderFactory.createEtchedBorder (),
                analysis +" Summary",
                TitledBorder.CENTER,
                TitledBorder.TOP));
		
	
		
		scrollPane.setPreferredSize(new Dimension(600, 300));
		table.setFillsViewportHeight(true);;
		
		MainUI.getInstance().updateStats(scrollPane);
	}
	/**Method creates and displays user defined requirements in a tabular format
	 * @param coins - an array list of user selected coins
	 * @param analysis - the type of analysis performed on the data
	 * @param interval - interval between data points
	 */
	private void createTimeSeries(ArrayList<Coin> coins, String analysis, String interval) {
		
		//Create a new TimeSeries array that will display all coin analysis data
		TimeSeries series[] = new TimeSeries[coins.size()];
		
		//Use a calendar and formatter to convert the string to date objects
		Calendar cal = Calendar.getInstance();
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		
		//For each coin
	    for (int i = 0; i < coins.size(); i++) {
			
	    	//Create a timeseries for the coin given it's name and interval
	    	series[i] = new TimeSeries(coins.get(i).getName() +" - " +interval);
			
	    	//For each data element within the coin
	    	for (int x = 0; x < coins.get(i).getData().size(); x++) {
				try {
					//Set the date of the calendar to the date of the current data element
					cal.setTime(formatter.parse(coins.get(i).getData().get(x).getDate()));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//Add the plot of the dataelement to the timeseries
				series[i].add(new Day(cal.getTime()), coins.get(i).getData().get(x).getData());
			}
			
		}
		
	    //Create a TimeSeriesCollection to store all of the creates timeseries
		TimeSeriesCollection dataset = new TimeSeriesCollection();
		
		//Store each coin's timesereis in the timesereiescollection dataset
		for (int x = 0; x < series.length; x++) {
			dataset.addSeries(series[x]);
		}

		//Create a new XYPlot
		XYPlot plot = new XYPlot();
		XYSplineRenderer splinerenderer1 = new XYSplineRenderer();
		
		//Set the data set of the plot to dataset
		plot.setDataset(0, dataset);
		plot.setRenderer(0, splinerenderer1);
		DateAxis domainAxis = new DateAxis("");
		plot.setDomainAxis(domainAxis);
		
		//Set the yAxisLabel of the plot initially to analysis
		String yAxisLabel = analysis;
		
		//If the yAxisLabel contains the word Percentage, replace the word Percentage with %
		if (yAxisLabel.contains("Percentage")) {
			yAxisLabel = yAxisLabel.replaceAll("Percentage", "%");
		}
		
		//If the yAxisLabel is Price, add (CAD) to the end of the string
		if (yAxisLabel.contentEquals("Price") || yAxisLabel.contentEquals("MarketCap")) {
			yAxisLabel = yAxisLabel.concat(" (CAD)");
		}
		
		//Create a number axis for the y-axis of the plot
		NumberAxis yAxis = new NumberAxis(yAxisLabel);
		
		//Set the auto rance and auto tick unit selection for the y-axis to true
		yAxis.setAutoRange(true);
		yAxis.setAutoTickUnitSelection(true);
		
		//Add the y-axis to the plot
		plot.setRangeAxis(yAxis);
		
		//Add a line for the y=0 for easier readability
		final Marker start = new ValueMarker(0.0);
		
		start.setPaint(Color.black);
		plot.addRangeMarker(start);
		JFreeChart chart = new JFreeChart(analysis+" Line Chart", new Font("Serif", java.awt.Font.BOLD, 18), plot,
				true);

		ChartPanel chartPanel = new ChartPanel(chart);
		chartPanel.setPreferredSize(new Dimension(600, 300));
		chartPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		chartPanel.setBackground(Color.white);
		
		MainUI.getInstance().updateStats(chartPanel);
	}
	
	/**
	 * createScatter() creates a scatter plot of the analysis data
	 * @param coins - an array list of user selected coins
	 * @param analysis - dates of which data to pull
	 * @param interval - interval between data points
	 */
	private void createScatter(ArrayList<Coin> coins, String analysis, String interval) {
		//Create a new TimeSeries array that will display all coin analysis data
		TimeSeries series[] = new TimeSeries[coins.size()];
	
	//Use a calendar and formatter to convert the string to date objects
	Calendar cal = Calendar.getInstance();
    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
	
	//For each coin
	for (int i = 0; i < coins.size(); i++) {
		
    	//Create a timeseries for the coin given it's name and interval
		series[i] = new TimeSeries(coins.get(i).getName() +" - " +interval);
		
    	//For each data element within the coin
		for (int x = 0; x < coins.get(i).getData().size(); x++) {
			try {
				
				//Set the date of the calendar to the date of the current data element
				cal.setTime(formatter.parse(coins.get(i).getData().get(x).getDate()));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Add the plot of the dataelement to the timeseries
			series[i].add(new Day(cal.getTime()), coins.get(i).getData().get(x).getData());
		}
	}
	
    //Create a TimeSeriesCollection to store all of the creates timeseries
	TimeSeriesCollection dataset = new TimeSeriesCollection();
	
	//Store each coin's timesereis in the timesereiescollection dataset
	for (int x = 0; x < series.length; x++) {
		dataset.addSeries(series[x]);
	}

	//Create a new XYPlot
	XYPlot plot = new XYPlot();
	XYItemRenderer itemrenderer1 = new XYLineAndShapeRenderer(false, true);

	//Set the data set of the plot to dataset
	plot.setDataset(0, dataset);
	plot.setRenderer(0, itemrenderer1);
	DateAxis domainAxis = new DateAxis("");
	plot.setDomainAxis(domainAxis);
	
	//Set the yAxisLabel of the plot initially to analysis
	String yAxisLabel = analysis;
	
	//If the yAxisLabel contains the word Percentage, replace the word Percentage with %
	if (yAxisLabel.contains("Percentage")) {
		yAxisLabel = yAxisLabel.replaceAll("Percentage", "%");
	}
	
	//If the yAxisLabel is Price, add (CAD) to the end of the string
	if (yAxisLabel.contentEquals("Price") || yAxisLabel.contentEquals("MarketCap")) {
		yAxisLabel = yAxisLabel.concat(" (CAD)");
	}
	
	//Create a number axis for the y-axis of the plot
	NumberAxis yAxis = new NumberAxis(yAxisLabel);
	
	//Set the auto rance and auto tick unit selection for the y-axis to true
	yAxis.setAutoRange(true);
	yAxis.setAutoTickUnitSelection(true);
	
	//Add the y-axis to the plot
	plot.setRangeAxis(yAxis); 
	
	//Add a line for the y=0 for easier readability
	final Marker start = new ValueMarker(0.0);
	start.setPaint(Color.black);
	plot.addRangeMarker(start);

	//plot.mapDatasetToRangeAxis(0, 0);// 1st dataset to 1st y-axis
	//plot.mapDatasetToRangeAxis(1, 1); // 2nd dataset to 2nd y-axis
	
	JFreeChart scatterChart = new JFreeChart(analysis+" Scatter Chart", new Font("Serif", java.awt.Font.BOLD, 18), plot,
			true);


	ChartPanel chartPanel = new ChartPanel(scatterChart);
	chartPanel.setPreferredSize(new Dimension(600, 300));
	chartPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
	chartPanel.setBackground(Color.white);
	MainUI.getInstance().updateStats(chartPanel);
}
	/**
	 * createBar() creates a bar graph of the analysis data
	 * @param coins - an array list of user selected coins
	 * @param analysis - dates of which data to pull
	 * @param interval - interval between data points
	 */
		private void createBar(ArrayList<Coin> coins, String analysis, String interval) {
			
			//Create a dataset to store the bar graph data for the coins
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			
			//For each coin
			for (int i = 0; i < coins.size(); i++) {
				
				//For each data element of each coin
				for (int y = 0; y < coins.get(i).getData().size(); y++) {
					
					//Add the value of the dataelement of the coin to the dataset
					dataset.setValue(coins.get(i).getData().get(y).getData(), coins.get(i).getName(), coins.get(i).getData().get(y).getDate());
					
				}
			}

			//Create a new plot for the bar graph
			CategoryPlot plot = new CategoryPlot();
			BarRenderer barrenderer1 = new BarRenderer();

			//Add the analysis dataset to the plot for the bar graph
			plot.setDataset(0, dataset);
			plot.setRenderer(0, barrenderer1);
			
			//Set the domain axis to be a category of date
			CategoryAxis domainAxis = new CategoryAxis("Date");
			plot.setDomainAxis(domainAxis);
			
			//Set the yAxisLabel of the plot initially to analysis
			String yAxisLabel = analysis;
			
			//If the yAxisLabel contains the word Percentage, replace the word Percentage with %
			if (yAxisLabel.contains("Percentage")) {
				yAxisLabel = yAxisLabel.replaceAll("Percentage", "%");
			}
			
			//If the yAxisLabel is Price, add (CAD) to the end of the string
			if (yAxisLabel.contentEquals("Price") || yAxisLabel.contentEquals("MarketCap")) {
				yAxisLabel = yAxisLabel.concat(" (CAD)");
			}
			
			//Create a number axis for the y-axis of the plot
			NumberAxis rangeAxis = new NumberAxis(yAxisLabel);
			
			//Set the auto rance and auto tick unit selection for the y-axis to true
			rangeAxis.setAutoRange(true);
			rangeAxis.setAutoTickUnitSelection(true);
			
			//Set the plot's range of the axis to the y-axis
			plot.setRangeAxis(rangeAxis);
			
			//Add a line for the y=0 for easier readability
			final Marker start = new ValueMarker(0.0);
			start.setPaint(Color.black);
			plot.addRangeMarker(start);

			JFreeChart barChart = new JFreeChart(interval +" " +analysis +" Bar Chart", new Font("Serif", java.awt.Font.BOLD, 18), plot,
					true);

			ChartPanel chartPanel = new ChartPanel(barChart);
			chartPanel.setPreferredSize(new Dimension(600, 300));
			chartPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
			chartPanel.setBackground(Color.white);
			MainUI.getInstance().updateStats(chartPanel);
		}



}
