/**
 * Edited By: Artur Krupa, Henry Chen
 * Student IDs: 251190423, 251166178 
 */
package cryptoAnalyzer.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.Vector;
import java.util.Date;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import cryptoAnalyzer.selection.*;
import cryptoAnalyzer.analysis.*;
import cryptoAnalyzer.coin.*;
import cryptoAnalyzer.database.AvailableCryptoList;

import java.util.Scanner;

public final class MainUI extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static MainUI instance;
	private JPanel stats;
	
	// Selections object stores users selections
	private Selections selections;
	
	private JTextArea selectedCryptoList;
	private JComboBox<String> cryptoList;
	private JComboBox<String> metricsList;
	private JComboBox<String> intervalList;
	private JDatePickerImpl datePicker;

	/**
	 * getInstance() returns a singleton instance of MainUI
	 * @return Returns a single MainUI object
	 */
	public static MainUI getInstance() {
		if (instance == null)
			instance = new MainUI();

		return instance;
	}

	/**
	 * MainUI() creates a new Main UI
	 */
	private MainUI() {
		
		// Set window title
		super("Crypto Analysis Tool");

		// Set top bar
		JLabel chooseCountryLabel = new JLabel("Choose a cryptocurrency: ");
		String[] cryptoNames = AvailableCryptoList.getInstance().getAvailableCryptos();
		cryptoList = new JComboBox<String>(cryptoNames);
		
		selections = new Selections();
		
		JButton addCrypto = new JButton("+");
		addCrypto.setActionCommand("add");
		addCrypto.addActionListener(this);
		
		JButton removeCrypto = new JButton("-");
		removeCrypto.setActionCommand("remove");
		removeCrypto.addActionListener(this);
		
		JPanel north = new JPanel();
		north.add(chooseCountryLabel);
		north.add(cryptoList);
		north.add(addCrypto);
		north.add(removeCrypto);
		

		// Set bottom bar
		JLabel from = new JLabel("From");
		UtilDateModel dateModel = new UtilDateModel();
		Properties p = new Properties();
		p.put("text.today", "Today");
		p.put("text.month", "Month");
		p.put("text.year", "Year");
		JDatePanelImpl datePanel = new JDatePanelImpl(dateModel, p);
		datePicker = new JDatePickerImpl(datePanel, new AbstractFormatter() {
			private String datePatern = "dd-MM-yyyy";

		    private SimpleDateFormat dateFormatter = new SimpleDateFormat(datePatern);

		    @Override
		    public Object stringToValue(String text) throws ParseException {
		        return dateFormatter.parseObject(text);
		    }

		    @Override
		    public String valueToString(Object value) throws ParseException {
		        if (value != null) {
		            Calendar cal = (Calendar) value;
		            return dateFormatter.format(cal.getTime());
		        }

		        return "";
		    }
		});
		
		JButton refresh = new JButton("Refresh");
		refresh.setActionCommand("refresh");
		refresh.addActionListener(this);

		JLabel metricsLabel = new JLabel("        Metrics: ");

		/**
		 * Analysis options the user can select from the drop down menu
		 */
		Vector<String> metricsNames = new Vector<String>();
		metricsNames.add("Price");
		metricsNames.add("MarketCap");
		metricsNames.add("Volume");
		metricsNames.add("Coins in Circulation");
		metricsNames.add("Percentage Change of Unit Price");
		metricsNames.add("Percentage Change of MarketCap Value");
		metricsNames.add("Percentage Change of Transaction Volume");
		metricsNames.add("Percentage Change of Coins in Circulation");
		metricsList = new JComboBox<String>(metricsNames);

		JLabel intervalLabel = new JLabel("        Choose interval: ");

		Vector<String> intervalNames = new Vector<String>();
		intervalNames.add("Daily");
		intervalNames.add("Weekly");
		intervalNames.add("Monthly");
		intervalNames.add("Yearly");

		intervalList = new JComboBox<String>(intervalNames);

		JPanel south = new JPanel();
		south.add(from);
		south.add(datePicker);
		
		south.add(metricsLabel);
		south.add(metricsList);

		south.add(intervalLabel);
		south.add(intervalList);
		south.add(refresh);
		
		JLabel selectedCryptoListLabel = new JLabel("List of selected cryptocurrencies: ");
		selectedCryptoList = new JTextArea(16, 10);
		JScrollPane selectedCryptoScrollPane = new JScrollPane(selectedCryptoList);
		JPanel east = new JPanel();
		east.setLayout(new BoxLayout(east, BoxLayout.Y_AXIS));
		east.add(selectedCryptoListLabel);
		east.add(selectedCryptoScrollPane);

		// Set charts region
		JPanel west = new JPanel();
		west.setPreferredSize(new Dimension(1250,650));
		stats = new JPanel();
		stats.setLayout(new GridLayout(2, 2));
		
		west.add(stats);

		getContentPane().add(north, BorderLayout.NORTH);
		getContentPane().add(east, BorderLayout.EAST);
		getContentPane().add(south, BorderLayout.SOUTH);
		getContentPane().add(west, BorderLayout.WEST);
	}
	
	/**
	 * updateStats() add the compnents to the main JPanel UI
	 * @param component The component to be added to the JPanel
	 */
	public void updateStats(JComponent component) {
		stats.add(component);
		stats.revalidate();
	}

	
	/**
	 * Method display() displays the main ui to the screen
	 */
	public static void display() {
		JFrame frame = MainUI.getInstance();
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		frame.setSize(900, 600);
		frame.pack();
		frame.setVisible(true);
	}

	/**
	 * actionPerformed listens for a button action and performs an task based on the given action
	 */
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("refresh".equals(command)) {

			//Check if a date has been selected
			if (datePicker.getModel().getValue() != null && !selections.getSelectedCrypto().isEmpty()){
				Date selectedDate = (Date)datePicker.getModel().getValue();

				//Check if the date is after today's date
				if (selectedDate.after(new Date())){
					
					//If so, clear the date input box
					datePicker.getModel().setValue(null);
					
					//Display error message to the user
					JOptionPane.showMessageDialog(null, "Invalid Date Selected, please enter a new date and try again.", "Error", 
                			JOptionPane.WARNING_MESSAGE);  
				}

				//If valid date is entered
				else{

					//Store user selections in the selections object
					selections.setAnalysis(metricsList.getSelectedItem().toString());
					selections.setInterval(intervalList.getSelectedItem().toString());
					selections.setStartDate((Date)datePicker.getModel().getValue());

					//Parse the user selections in selection reader
					SelectionReader selectReader = new SelectionReader(selections);
					
					//Create an analysis object to perform analysis on the selections in selection reader
					Analysis analysis = AnalysisFactory.getAnalysis(selectReader);
					
					//Perform analysis on the coins
					analysis.analysis();
					
//					for (Coin coin : analysis.getCoins()) {
//						for (DataElement data : coin.getData()) {
//							System.out.println("Coin: " +coin.getName() +", Date: " +data.getDate() +", Interval: " +selectReader.getInterval() +", " +selectReader.getAnalysis() +": " +data.getData());
//						}
//					}
					
					//Clear previous stats
					stats.removeAll();
					
					//Create a new visualization object
					DataVisualizationCreator creator = new DataVisualizationCreator();
					
					//Create charts of the analysis data
					creator.createCharts(analysis.getCoins(), selections.getAnalysis(), selections.getInterval());
				}
		}

		} else if ("add".equals(command)) {
			
			//Check if the crypto list does not already contains the coin we wish to add
			if (!selections.getSelectedCrypto().contains(cryptoList.getSelectedItem().toString())) {
					
					String check = cryptoList.getSelectedItem().toString();
					boolean flag = false;
					
					//Check if the coin we wish to add to the selected list is allowed to be selected
					Scanner sc = new Scanner(this.getClass().getResourceAsStream("/Allowed_crypto.txt"));
			    	while(sc.hasNextLine()) {
			    		String line = sc.nextLine();
			    		
			    		//If the coin is found in the not allowed list, set the flag to true
			    		if(line.equals(check)) {
			    			flag = true;
			    		}
			    	}
			    	
			    	//If the coin is not allowed to be added, display error message
			    	if(flag == false) {
			    		JOptionPane.showMessageDialog(null, "Sorry, but that crypto currency is not allowed to be fetched.", "Error", 
	                			JOptionPane.WARNING_MESSAGE);
			    	} 
			    	
			    	//If the coin is allowed to be added, add it to the selections list and display the coin on the coins selection section
			    	else {
						selections.addCrypto(cryptoList.getSelectedItem().toString());
						String text = "";
						for (String crypto: selections.getSelectedCrypto())
							text += crypto + "\n";
					
						selectedCryptoList.setText(text);
			    	}

			}
		} else if ("remove".equals(command)) {
			selections.removeCrypto(cryptoList.getSelectedItem().toString());
			String text = "";
			for (String crypto: selections.getSelectedCrypto())
				text += crypto + "\n";
			
			selectedCryptoList.setText(text);
		}
	}

	

}
