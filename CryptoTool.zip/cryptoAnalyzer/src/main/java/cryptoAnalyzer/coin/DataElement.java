package cryptoAnalyzer.coin;

import java.io.Serializable;

/**
 * DataElement class represents a data element that stores a unit of analysis data
 * DataElement implements Serializable to allow the data elements to be stored in the database
 * @author Artur Krupa
 *
 */
public class DataElement implements Serializable{
	
	//CLASS VARIABLES
	
	//serialVersionUID used for the Serializable implementations
	private static final long serialVersionUID = 1L;
	
	//date stores the date of the analysis data
	private String date;
	
	//data stores the value of the analysis data
	private double data;
	
	//analysis stores the type of analysis that was performed, represents the type of data stored.
	private String analysis;
	
	/**
	 * DataElement creates a new DataElement of type analysis, at point date, with value data
	 * @param analysis The type of information the data element is storing
	 * @param date The data of the analysis data
	 * @param data The value of the data
	 */
	public DataElement(String analysis, String date, double data) {
		this.date = date;
		this.data = data;
		this.analysis = analysis;
	}
	
	//METHODS
	
	/**
	 * getType() returns the type of data contained in the data element
	 * @return The type of analysis data
	 */
	public String getType() {
		return analysis;
	}
	
	/**
	 * getDate() returns the date of the analysis data
	 * @return The date of the analysis data
	 */
	public String getDate() {
		return date;
	}
	
	/**
	 * getData() returns the value of the analysis data
	 * @return The value of the analysis 
	 */
	public double getData() {
		return data;
	}

}
