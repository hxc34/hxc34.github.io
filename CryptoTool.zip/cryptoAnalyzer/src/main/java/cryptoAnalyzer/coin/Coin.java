/**
 * Coin class:  Represents a crypto coin and the analysis of the data on that coin
 * Created by: Artur Krupa
 * Student ID: 251190423
 */

package cryptoAnalyzer.coin;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Class Coin represents a cryptocurrency coin and all of it's information and data of the analysis performed on the coin
 * Coin implements Serializable to allow the coins to be stored in the database
 * @author Artur Krupa
 * Student ID: 251190423
 *
 */
public class Coin implements Serializable{
	
	//CLASS VARIABLES
	
	//serialVersionUID used for the Serializable implementations
	private static final long serialVersionUID = 1L;
	
	//name stores the name of the coin
	private String name;
	
	//List data stores a list of all of the analysis information done on the coin
	private ArrayList<DataElement> data;
	
	//CONSTRUCTOR
	
	/**
	 * Coin creates a new coin with a given name, ID, and list of data
	 * @param name The name of the coin
	 * @param data The list of analysis data on the coin
	 */
	public Coin(String name, ArrayList<DataElement> data) {
		this.name = name;
		this.data = data;
	}
	
	//METHODS
	
	/**
	 * getName() returns the name of the coin
	 * @return The name of the coin
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * setData method allows us to set the list of analysis data of the coin
	 * @param data The list of data to store in the coin
	 */
	public void setData(ArrayList<DataElement> data) {
		this.data = data;
	}
	
	/**
	 * getData() returns the list of analysis data on the coin
	 * @return The list of analysis data on the coin
	 */
	public ArrayList<DataElement> getData() {
		return data;
	}

}
