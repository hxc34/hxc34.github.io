package cryptoAnalyzer.database;

import cryptoAnalyzer.adapter.AdapterMarketCap;
import cryptoAnalyzer.adapter.AdapterPrice;
import cryptoAnalyzer.adapter.AdapterVolume;

/**
 * DataVisualizationCreator
 * @author contributions by: Xu Wang,
 *DataFetcher responds to a data fetching call
 */
public class DataFetcher {
	
	/**Method responds to a data call by calling adapter class and returning price
	 * @param id - id of the selected cryptocurrency
	 * @param date - dates of which data to pull
	 * @return price data object
	 */
	public double getPriceForCoin(String id, String date) {
        double price = 0.0;
        /**
         *adapter object is created and subsequently called upon. This will allow to future updates for internal database to receive 
         *data from multiple sources
         */
        AdapterPrice adapter = new AdapterPrice();
        price = adapter.getPriceForCoin(id, date);
        return price;
    }
	
	/**Method responds to a data call by calling adapter class and returning price
	 * @param id - id of the selected cryptocurrency
	 * @param date - dates of which data to pull
	 * @return market cap data object 
	 */
    public double getMarketCapForCoin(String id, String date) {
        double marketCap = 0.0;
        /**
         *adapter object is created and subsequently called upon. This will allow to future updates for internal database to receive 
         *data from multiple sources
         */
        AdapterMarketCap adapter = new AdapterMarketCap();
        marketCap = adapter.getMarketCapForCoin(id, date);
        return marketCap;
    }
	/**Method responds to a data call by calling adapter class and returning price
	 * @param id - id of the selected cryptocurrency
	 * @param date - dates of which data to pull
	 * @return volume data object
	 */
    
    public double getVolumeForCoin(String id, String date) {
        double volume = 0.0;
        /**
         *adapter object is created and subsequently called upon. This will allow to future updates for internal database to receive 
         *data from multiple sources
         */
        AdapterVolume adapter = new AdapterVolume();
        volume = adapter.getVolumeForCoin(id, date);
        return volume;
    }
}
