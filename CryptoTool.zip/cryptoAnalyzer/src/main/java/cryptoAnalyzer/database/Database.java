package cryptoAnalyzer.database;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectOutput;
import java.io.StreamCorruptedException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import cryptoAnalyzer.coin.*;

/**
 * Database.java: This static class represents an intermediary database between the Coingecko server and the application
 * which stores previous Coingecko request data for future reuse
 * @author Artur Krupa
 *
 */
public final class Database {
	
	//CLASS VARIABLES
	
	//instance allows us to store a single instance of Datavase, to allow for singleton Database
	private static Database instance = null;
	
	//The coins hash map stores all of the information stored in the database
	private HashMap<String, Coin> coins = null;
	
	//The fetcher allows the database to query Coingecko for information it does not contain
	private DataFetcher fetcher = new DataFetcher();
	
	//The location and name of the database file
	private String filename = "Coin_database";
	
	//Stores the database file as a java file
	private File database = new File(filename);
	
	//formatter allow us to check current date
    private SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
	
	//CONSTRUCTOR
	
	/**
	 * private Database constructor to only create a new Database if instance is null, created through getInstance method
	 */
	private Database() {}
	
	//METHODS
	
	/**
	 * getInstance() returns the single object instance of Database
	 * @return The Database object
	 */
	public static Database getInstance() {
		if (instance == null) {
			instance = new Database();
		}
		
		return instance;
	}
	
	/**
	 * Private Static method read reads from the coin database file and stores the information from the file in the coin hash map
	 */
	@SuppressWarnings("unchecked")
	private void read() {

		  ObjectInputStream input = null;
		  try {
		
			  //Read from the file
		   input = new ObjectInputStream(new FileInputStream(database));
		   
		   //Set the coins hash map to the hash map read from the file
		   coins = (HashMap<String, Coin>) input.readObject();
		   input.close();
		   
		   //If an error occurs reading the file, then he just create a new hash map to store the coin data, which will be written to the file later
		  } catch (StreamCorruptedException e) {
			  coins = new HashMap<String, Coin>();
		  } catch (FileNotFoundException e) {
			  coins = new HashMap<String, Coin>();
		  } catch (IOException e) {
			  coins = new HashMap<String, Coin>();
		  } catch (ClassNotFoundException e) {
			  coins = new HashMap<String, Coin>();
		  }
	}
	
	/**
	 * Private Static method void write saves the updated and current hash map to the database file
	 */
	 private void write() {

		  ObjectOutput out = null;

		  try {
			  //Create a new output stream to our database file
		   out = new ObjectOutputStream(new FileOutputStream(database));
		   
		   //Write the coins hash map to the file
		   out.writeObject(coins);
		   out.close();
		  } catch (FileNotFoundException e) {
			  e.printStackTrace();
		  } catch (IOException e) {
		   e.printStackTrace();
		  }
	}
	
	/**
	 * Static getPriceForCoin returns the price of a given coin on a specified date
	 * @param name The name of the coin we wish to get the price of
	 * @param date The date of which we want the price of the coin from
	 * @return The price of the coin on the specified date
	 */
	public double getPriceForCoin(String name, String date) {
		
		//Read from the database file, and update the coins hash map
		read();
		
		//Get the specified coin from the hash map and store it in coin
		Coin coin = coins.get(name);
		
		//If the coin is null, meaning the hash map and database does not contain data on the coin we want information about
		if(coin == null) {
			
			//Fetch the price of this coin on the date and store it in value
			double value = fetcher.getPriceForCoin(AvailableCryptoList.getInstance().getCryptoID(name), date);
			
			//If the value of the coin is not a valid value, as the CoinGecko api may be overrun and constantly return 0, or the date of the data is today's date, and may later change
			if (value != 0.0 && !date.contentEquals(formatter.format(new Date()))) {
				
				//Create a new coin to store the new data about the cryptocurrency in our database
				Coin newCoin = new Coin(name, null);
				
				//Create a new data list for the coin, store the newly obtained value, and store the coin in the database
				ArrayList<DataElement> temp = new ArrayList<DataElement>();
				temp.add(new DataElement("Price", date, value));
				newCoin.setData(temp);
				coins.put(name, newCoin);
				
				//Write the changes to the hashmap to the database file
				write();
			}
			
			//Return the obtained value
			return value;
		}
		
		//If the coin does exist within the database
		else {
			//Go through each data element of the coin that is in the database
			for (int x = 0; x < coin.getData().size(); x++) {
				
				//If the data of the coin in the database matches the type of data we are looking for and the date we want the data from
				if (coin.getData().get(x).getType().contentEquals("Price") && coin.getData().get(x).getDate().contentEquals(date)) {
					
					//Return the stored value in the database
					return coin.getData().get(x).getData();
				}
			}
			
			//If the coin exists in the database but the desired information does not
			//Get the desired information from coingecko
			double newData = fetcher.getPriceForCoin(AvailableCryptoList.getInstance().getCryptoID(name), date);
			
			//If the retrieved data from Coingecko is valid, and the data is not from today's date, store it in the database
			if (newData != 0.0 && !date.contentEquals(formatter.format(new Date()))) {
				DataElement addData = new DataElement("Price", date, newData);
				coin.getData().add(addData);
				write();
			}
			
			//Return the retrieved information
			return newData;
		}
	}
	
	/**
	 * Static getMarketCapForCoin() returns the market cap value of a specified coin on a specified date
	 * @param name The name of the coin we want to get the data about
	 * @param date The data of which we want the data from
	 * @return The market cap of the specified coin on the specified date
	 */
	public double getMarketCapForCoin(String name, String date) {
		
		//Read from the database file, and update the coins hash map
		read();
		
		//Get the specified coin from the hash map and store it in coin
		Coin coin = coins.get(name);
		
		//If the coin is null, meaning the hash map and database does not contain data on the coin we want information about
		if(coin == null) {
			
			//Fetch the market cap of this coin on the date and store it in value
			double value = fetcher.getMarketCapForCoin(AvailableCryptoList.getInstance().getCryptoID(name), date);
			
			//If the value of the coin is not a valid value, as the CoinGecko api may be overrun and constantly return 0, or the date of the data is today's date, and may later change
			if (value != 0.0 && !date.contentEquals(formatter.format(new Date()))) {
				
				//Create a new coin to store the new data about the cryptocurrency in our database
				Coin newCoin = new Coin(name, null);
				
				//Create a new data list for the coin, store the newly obtained value, and store the coin in the database
				ArrayList<DataElement> temp = new ArrayList<DataElement>();
				temp.add(new DataElement("MarketCap", date, value));
				newCoin.setData(temp);
				coins.put(name, newCoin);
				
				//Write the changes to the hashmap to the database file
				write();
			}
			
			//Return the obtained value
			return value;
		}
		
		//If the coin does exist within the database
		else {
			//Go through each dataelement of the coin that is in the database
			for (int x = 0; x < coin.getData().size(); x++) {
				
				//If the data of the coin in the database matches the type of data we are looking for and the date we want the data from
				if (coin.getData().get(x).getType().contentEquals("MarketCap") && coin.getData().get(x).getDate().contentEquals(date)) {
					
					//Return the stored value in the database
					return coin.getData().get(x).getData();
				}
			}
			
			//If the coin exists in the database but the desired information does not
			//Get the desired information from coingecko
			double newData = fetcher.getMarketCapForCoin(AvailableCryptoList.getInstance().getCryptoID(name), date);
			
			//If the retrieved data from Coingecko is valid, and the data is not from today's date, store it in the database
			if (newData != 0.0 && !date.contentEquals(formatter.format(new Date()))) {
				DataElement addData = new DataElement("MarketCap", date, newData);
				coin.getData().add(addData);
				write();
			}
			
			//Return the retrieved information
			return newData;
		}
	}
	
	/**
	 * Static getVolumeForCoin returns the volume of a specified coin on a specified date
	 * @param name The name of the coin we wish to get the volume of
	 * @param date The date at which we wish to get the volume of
	 * @return The volume of the specified coin on the specified date
	 */
	public double getVolumeForCoin(String name, String date) {
		
		//Read from the database file, and update the coins hash map
		read();
		
		//Get the specified coin from the hash map and store it in coin
		Coin coin = coins.get(name);
		
		//If the coin is null, meaning the hash map and database does not contain data on the coin we want information about
		if(coin == null) {
			
			//Fetch the volume of this coin on the date and store it in value
			double value = fetcher.getVolumeForCoin(AvailableCryptoList.getInstance().getCryptoID(name), date);
			
			//If the value of the coin is not a valid value, as the CoinGecko api may be overrun and constantly return 0, or the date of the data is today's date, and may later change
			if (value != 0 && !date.contentEquals(formatter.format(new Date()))) {
				
				//Create a new coin to store the new data about the cryptocurrency in our database
				Coin newCoin = new Coin(name, null);
				
				//Create a new data list for the coin, store the newly obtained value, and store the coin in the database
				ArrayList<DataElement> temp = new ArrayList<DataElement>();
				temp.add(new DataElement("Volume", date, value));
				newCoin.setData(temp);
				coins.put(name, newCoin);
				
				//Write the changes to the hashmap to the database file
				write();
			}
			
			//Return the obtained value
			return value;
		}
		
		//If the coin does exist within the database
		else {
			//Go through each dataelement of the coin that is in the database
			for (int x = 0; x < coin.getData().size(); x++) {
				
				//If the data of the coin in the database matches the type of data we are looking for and the date we want the data from
				if (coin.getData().get(x).getType().contentEquals("Volume") && coin.getData().get(x).getDate().contentEquals(date)) {
					
					//Return the stored value in the database
					return coin.getData().get(x).getData();
				}
			}
			
			//If the coin exists in the database but the desired information does not
			//Get the desired information from coingecko
			double newData = fetcher.getVolumeForCoin(AvailableCryptoList.getInstance().getCryptoID(name), date);
			
			//If the retrieved data from Coingecko is valid, and the data is not from today's date, store it in the database
			if (newData != 0.0 && !date.contentEquals(formatter.format(new Date()))) {
				DataElement addData = new DataElement("Volume", date, newData);
				coin.getData().add(addData);
				write();
			}
			
			//Return the retrieved information
			return newData;
		}
	}
	
	

}
