package cryptoAnalyzer.analysis;

import java.util.ArrayList;

import cryptoAnalyzer.coin.Coin;
import cryptoAnalyzer.coin.DataElement;
import cryptoAnalyzer.selection.*;
import cryptoAnalyzer.database.*;

/**
 * Class CirculationAnalysis returns the associated coin circulation value that a coin has over a period of dates.
 * @author Henry Chen
 * Student ID: 251166178
 */
public class CirculationAnalysis extends Analysis {
	
	protected SelectionReader selections;
	protected ArrayList<Coin> coins;
	private ArrayList<DataElement> data;
	/**
 	* This constructor method sets the class variable selections to a given value that it recieves.
    * @param selections - contains user input
 	*/
	public CirculationAnalysis(SelectionReader selections) {
		this.selections = selections;
	}
   /**
    * This method fills the class variable coins with coin objects that all correspond to certain dates. 
    * Each coin object contains a name of the coin, and the associated data(circulation value) from a date.
 	*/
	@Override
	public void analysis() {
		coins = new ArrayList<Coin>();
		for (String name : selections.getSelectedCrypto()) {
			data = new ArrayList<DataElement>();
			for (String date : selections.getDates()) {
				data.add(new DataElement("Coins in Circulation" ,date, Database.getInstance().getMarketCapForCoin(name, date) / Database.getInstance().getPriceForCoin(name, date)));
			}
			
			coins.add(new Coin(name, data));
			}
	}
   /**
	* This method returns the class variable coins, which holds coin objects that each have a name and data(circulatiion value).
	* @return Class coins variable
 	*/
	public ArrayList<Coin> getCoins() {
		return coins;
	}
	
}
