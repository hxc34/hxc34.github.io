package cryptoAnalyzer.analysis;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import cryptoAnalyzer.coin.Coin;
import cryptoAnalyzer.coin.DataElement;
import cryptoAnalyzer.selection.*;

/**
 * Class PCCirculationAnalysis calculates the percentage change of the coin circulation of a coin over a given interval
 * PCCirculationAnalysis extends CirculationAnalysis as PCCirculationAnalysis inherits analysis information performed by CirculationAnalysis
 * @author Artur Krupa
 *
 */
public class PCCirculationAnalysis extends CirculationAnalysis {
	
	//CONSTRUCTOR
	
	/**
	 * PCCirculationAnalysis calculates the percentage of the coin circulation of a coin given by selections
	 * @param selections The user's selections containing the coin, dates, interval and analysis type to be performed
	 */
	public PCCirculationAnalysis(SelectionReader selections) {
		
		//Call the super class, passing it the user's selections
		super(selections);
		
		//Get the user's selected starting date from selections
		String startDate = super.selections.getDates().get(0);
		
		//Convert startDate back into a date object to allow us to modify the start date
		  Calendar cal = Calendar.getInstance();
	      SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
	      try {
			cal.setTime(formatter.parse(startDate));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      
	      /*In order to perform percent change properly, we must get the data of the coin 1 interval before the users
	       * selected start date to be able to calculate percent change on the desired start date
	       * Depending on the users selected interval, we go back a specified amount of days from the users start date
	       * to grab the required information
	       */
	       if (selections.getInterval().contentEquals("Daily")){
	           cal.add(Calendar.DATE, -1);
	       }
	       else if (selections.getInterval().contentEquals("Weekly")){
	    	   cal.add(Calendar.DATE, -7);
	            
	       }
	       else if (selections.getInterval().contentEquals("Monthly")){
	    	   cal.add(Calendar.DATE, -30);
	            
	       }
	       else if (selections.getInterval().contentEquals("Yearly")){
	    	   cal.add(Calendar.DATE, -365);
	  
	       }
	    
	       //Create a new user selections to store the modified users selections
	       Selections updated = new Selections();
	       
	       //Copy all of the user's selected crypto from selections into the updated, modified selections
	       for (String name : selections.getSelectedCrypto()) {
	    	   updated.addCrypto(name);
	       }
	       
	       //Copy the rest of the required information from selections
	       updated.setAnalysis(selections.getAnalysis());
	       updated.setInterval(selections.getInterval());
	       updated.setStartDate(cal.getTime());
	       
	       //Create a new SelectionReader of the updated selections, and set the super class' selections to it
	       super.selections = new SelectionReader(updated);
		
	       //Tell the super class to perform it's analysis on the modified user selections
	       super.analysis();
	}
	
	/**
	 * analysis() performs percent change of coin circulation analysis on all coins stored in the superclass' coin list
	 */
	public void analysis() {		
		
		//For every coin in the coins list
		for(Coin coin : coins) {
			
			//Create a new list of DataElements to store the new analysis data
			ArrayList<DataElement> temp = new ArrayList<DataElement>();
			
			//For each piece of data on coin circulation on the coin
			for (int i = 1; i < coin.getData().size(); i++) {
				
				//Calculate the percent change of coin circulation and add it to the new DataElement list
				temp.add(new DataElement("Percentage Change of Coins in Circulation", coin.getData().get(i).getDate(), (((coin.getData().get(i).getData() - coin.getData().get(i-1).getData())/coin.getData().get(i-1).getData())*100)));
			}
			
			//Set the data list of the coin to the new data list
			coin.setData(temp);
		}
	}
}
