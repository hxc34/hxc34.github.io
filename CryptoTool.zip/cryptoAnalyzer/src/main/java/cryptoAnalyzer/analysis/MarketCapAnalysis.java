package cryptoAnalyzer.analysis;

import java.util.ArrayList;

import cryptoAnalyzer.coin.Coin;
import cryptoAnalyzer.coin.DataElement;
import cryptoAnalyzer.selection.*;
import cryptoAnalyzer.database.*;

/**
 * Class MarketCapAnalysis returns the associated market cap value that a coin has over a period of dates.
 * @author Henry Chen
 */

public class MarketCapAnalysis extends Analysis {
	
	protected SelectionReader selections;
	protected ArrayList<Coin> coins;
	private ArrayList<DataElement> data;
	/**
 	* This constructor method sets the class variable selections to a given value that it recieves.
    * @param selections - contains user input
 	*/
	public MarketCapAnalysis(SelectionReader selections) {
		this.selections = selections;
	}
  	/**
 	* This method fills the class variable coins with coin objects that all correspond to certain dates. 
    * Each coin object contains a name of the coin, and the associated data(market cap value) from a date.
 	*/
	@Override
	public void analysis() {
		coins = new ArrayList<Coin>();
		for (String name : selections.getSelectedCrypto()) {
			data = new ArrayList<DataElement>();
			for (String date : selections.getDates()) {
				data.add(new DataElement("MarketCap",date, Database.getInstance().getMarketCapForCoin(name, date)));
			}
			
			coins.add(new Coin(name, data));
			}
	}
	 /**
 	* This method returns the class variable coins, which holds coin objects that each have a name and data(market cap value).
	* @return Class coins variable
 	*/
	public ArrayList<Coin> getCoins() {
		return coins;
	}
		
}
