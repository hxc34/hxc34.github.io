package cryptoAnalyzer.analysis;

import java.util.ArrayList;

import cryptoAnalyzer.coin.Coin;

/**
 * Analysis: An abstract class to define our analysis subclasses
 * @author Artur Krupa
 *
 */

public abstract class Analysis {
	
	/**
	 * Abstract method analysis() will compute our desired analysis
	 */
	public abstract void analysis();
	
	/**
	 * Abstract method getCoins returns our specified coins with their analysis information
	 * @return A list of coins storing their analysis data
	 */
	public abstract ArrayList<Coin> getCoins();
	
}
