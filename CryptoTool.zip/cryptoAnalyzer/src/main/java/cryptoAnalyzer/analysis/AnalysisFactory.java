package cryptoAnalyzer.analysis;

import cryptoAnalyzer.selection.*;

/**
 * @author Xu Wang
 * Student ID: 250748901
 * This class creates and returns a apporpriate analysis object, the analsis object determine by what data is passed into this class.
 * In order to do so, this class calls an appropriate analysis subclass in order to be able to return an appropriate analysis object.
 */
public class AnalysisFactory {
	
	/** This class takes in data, and calls a appropirate method to return an appropriate data object in accordance with the input data. 
	 * @param selection - contains the user input
	 * @return relevant analysis object through factory design pattern
	 */
    public static Analysis getAnalysis(SelectionReader selection){

       /**
        * below are the 8 configurations of analysis that the user can choose and the factory will 
        * create and return the correct analysis object
        */
    if(selection.getAnalysis().contentEquals("Price")){
        return new PriceAnalysis(selection);
       }
    if(selection.getAnalysis().contentEquals("Percentage Change of Unit Price")){
        return new PCPriceAnalysis(selection);
     }
     if(selection.getAnalysis().contentEquals("MarketCap")){
        return new MarketCapAnalysis(selection);
     }
     if(selection.getAnalysis().contentEquals("Percentage Change of MarketCap Value")){
        return new PCMarketCapAnalysis(selection);
     }
     if(selection.getAnalysis().contentEquals("Volume")){
        return new TransactionVolumeAnalysis(selection);
     }
     if(selection.getAnalysis().contentEquals("Percentage Change of Transaction Volume")){
        return new PCTransactionVolumeAnalysis(selection);
     }
     if(selection.getAnalysis().contentEquals("Coins in Circulation")){
        return new CirculationAnalysis(selection);
     }
     if(selection.getAnalysis().contentEquals("Percentage Change of Coins in Circulation")){
        return new PCCirculationAnalysis(selection);
     }
       return null;
    }
 }
